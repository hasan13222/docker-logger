export type TUser = {
  _id?: string;
  email: string;
  password: string;
  profilePhoto?: string;
  createdAt?: Date;
  updatedAt?: Date;
};
